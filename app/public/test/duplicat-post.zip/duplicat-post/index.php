<?php

/**
  * Plugin Name: Duplicat Post
  * Plugin URI:  https://github.com/jchristopher/attachments
  * Description: It's just a dupkicat post plugin for demo project
  * Author:      Rayhan Uddin chowdhury
  * Author URI:  http://mondaybynoon.com/
  * Version:     1.0
  * Text Domain: attachments
  * Domain Path: /languages/
  * License:     GPLv2 or later
  * License URI: http://www.gnu.org/licenses/gpl-2.0.html
  */